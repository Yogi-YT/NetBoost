================================================================================
                    NetBoost v1.0 - Gaming Network Optimizer
================================================================================

improve your Network and Gaming performance!

================================================================================
                              QUICK START
================================================================================

1. Extract the folder
2. Right-click "NetBoost.exe"
3. Click "Run as Administrator"
4. Accept the Terms of Service
5. Click "Create Restore Point" (IMPORTANT!)
6. Click "Optimize Now"
7. Restart your PC
8. Enjoy better performance!

================================================================================
                             WHAT IT DOES
================================================================================

NetBoost applies proven optimizations:

NETWORK OPTIMIZATIONS:
  - Disables Nagle's Algorithm (reduces packet delay)
  - Removes network throttling (unlocks full speed)
  - Optimizes TCP/IP settings
  - Removes QoS bandwidth limits
  - Sets fast DNS (Google & Cloudflare)
  - Optimizes MTU size

SYSTEM OPTIMIZATIONS:
  - Enables Windows Game Mode
  - Sets Ultimate Performance power plan
  - Disables Windows telemetry
  - Disables Cortana
  - Removes bloatware apps

================================================================================
                               IS IT SAFE?
================================================================================

YES! NetBoost is 100% safe:

  ✓ All changes are reversible (YOU have to create a restore point first before applying optimizations.)
  ✓ No data collection or telemetry
  ✓ Open source code
  ✓ No viruses or malware

TO UNDO:
  - Click "Undo Changes" button in NetBoost
  - OR: Press Windows+R, type "rstrui.exe", select restore point

================================================================================
                              REQUIREMENTS
================================================================================

  - Windows 10 or Windows 11
  - Administrator privileges (must right-click > Run as Administrator)
  - 20 MB free disk space
  - Internet connection (for DNS changes)

================================================================================
                              INSTRUCTIONS
================================================================================

STEP 1: CREATE RESTORE POINT (IMPORTANT!)
  a) Run NetBoost as Administrator
  b) Click "Optimize Now"
  c) Click "Create Restore Point"
  d) Wait 30-60 seconds for completion

STEP 2: RUN OPTIMIZATIONS
  a) Click "Optimize Now" again
  b) Watch as optimizations apply
  c) pop-up notification appears when done
  d) RESTART YOUR PC for changes to take effect

================================================================================
                              TROUBLESHOOTING
================================================================================

"Not running as Administrator"
  → Right-click NetBoost.exe → Run as Administrator

"Some features disabled"
  → You must run as Administrator for optimizations to work

"Changes not applying"
  → Make sure you restarted your PC after optimization

"Still have high ping"
  → Your ISP connection speed is the main factor
  → NetBoost reduces local network delays, not ISP speed
  → Try Ethernet instead of Wi-Fi

================================================================================
                                SUPPORT
================================================================================

Need help?

Discord: https://discord.com/invite/GypprwPgcP
Email: yogiyt.marketing@gmail.com

================================================================================
                            FILES INCLUDED
================================================================================

NetBoost.exe           - Main program
README.txt             - This file

================================================================================
                               CREDITS
================================================================================

NetBoost v1.0
Made by @yogiyt

© 2026 NetBoost. All rights reserved.
Free for personal use. Do not redistribute without permission.

Made with ❤️ for gamers

================================================================================

Thank you for using NetBoost! Enjoy your lower latency and better gaming! 🚀

================================================================================
